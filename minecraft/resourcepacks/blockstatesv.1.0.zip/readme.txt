----------------[Terms of use]---------------------------

You may use everything I made in this pack if you credit me properly

----------------[Credit]---------------------------


--Pack Creator:--

mr_ch0c0late

Curse Forge: 		https://www.curseforge.com/members/mr_ch0c0late1
Planet Minecraft: 	https://www.planetminecraft.com/member/mr_ch0c0late1/
Twitter: 			https://twitter.com/mr_ch0c0late1


--Special Thanks to:--

Zartrix

Curse Forge:		https://www.curseforge.com/members/zartrix
Planet Minecraft: 	https://www.planetminecraft.com/member/zartrix/
Reddit: 			https://www.reddit.com/user/Zartrix